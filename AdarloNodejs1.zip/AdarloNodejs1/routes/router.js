const express = require('express');
const router = express.Router();
const page = require('../controller/AppController');

router.get('/', page.index);
router.get('/about', page.about);
router.get('/blog', page.blog);
router.get('/contact', page.contact);
router.get('/pages', page.pages);
module.exports = router;